<?php

//
// New Post Type
//


add_action('init', 'waxom_testimonial_register');  

function waxom_testimonial_register() {
    $args = array(
        'label' => esc_html__('Testimonials', 'waxom'),
        'public' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => true,
        'rewrite' => true,
        'menu_icon' => 'dashicons-format-quote',
        'supports' => array('title','thumbnail')
       );  

    register_post_type( 'testimonials' , $args );
}


//
// Thumbnail column
//



//
// Testimonial Title and Caption
//

add_action("admin_init", "waxom_testimonial_title_settings");   

function waxom_testimonial_title_settings(){
    add_meta_box("testimonial_title_settings", "Testimonial", "waxom_testimonial_title_config", "testimonials", "normal", "high");
}   

function waxom_testimonial_title_config(){
        global $post;
        if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return $post_id;
        $custom = get_post_custom($post->ID);
		
		if(isset($custom["testimonial_content"][0])) $testimonial_content = $custom["testimonial_content"][0];
		if(isset($custom["role"][0])) $role = $custom["role"][0];
		if(isset($custom["name"][0])) $name = $custom["name"][0];
?>
	<div class="metabox-options form-table fullwidth-metabox image-upload-dep">
		
		<div class="metabox-option">
			<h6><?php esc_html_e('Name', 'waxom') ?>:</h6>
			<input type="text" name="name" value="<?php echo esc_textarea($name); ?>">
		</div>		
		
		<div class="metabox-option">
			<h6><?php esc_html_e('Subline', 'waxom') ?>:</h6>
			<input type="text" name="role" value="<?php echo esc_textarea($role); ?>">
		</div>
		
		<div class="metabox-option">
			<h6><?php esc_html_e('Testimonial', 'waxom') ?>:</h6>
			<textarea name="testimonial_content"><?php echo esc_textarea($testimonial_content); ?></textarea>
		</div>
		
	</div>
<?php
    }	
	
	
// Save Slide
	
add_action('save_post', 'waxom_save_testimonial_meta'); 

function waxom_save_testimonial_meta(){
    global $post;  	
	
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ){
		return $post_id;
	}else{
	
		$post_metas = array('name','role','testimonial_content');
		
		foreach($post_metas as $post_meta) {
			if(isset($_POST[$post_meta])) update_post_meta($post->ID, $post_meta, $_POST[$post_meta]);
		}
    }

}