<?php

//
// New Post Type
//


add_action('init', 'vntd_slider_register');  

function vntd_slider_register() {
    $args = array(
        'label' => esc_html__('Veented Slider', 'waxom'),
        'public' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => true,
        'rewrite' => true,
        'menu_icon' => 'dashicons-format-gallery',
        'supports' => array('title','thumbnail')
       );  

    register_post_type( 'vntd_slider' , $args );
    
    register_taxonomy(
    	"slide-locations", 
    	array("vntd_slider"), 
    	array(
    		"hierarchical" => true, 
    		"context" => "normal", 
    		'show_ui' => true,
    		"label" => "Slide Locations", 
    		"singular_label" => "Slide Location", 
    		"rewrite" => true
    	)
    );
}


//
// Thumbnail column
//

add_filter( 'manage_edit-vntd_slider_columns', 'vntd_slider_columns_settings' ) ;

function vntd_slider_columns_settings( $columns ) {

	$columns = array(
		'cb' => '<input type="checkbox" />',
		'title' => esc_html__('Title', 'waxom'),
		'date' => esc_html__('Date', 'waxom'),
		'thumbnail' => ''	
	);

	return $columns;
}

add_action( 'manage_vntd_slider_posts_custom_column', 'vntd_slider_columns_content', 10, 2 );

function vntd_slider_columns_content( $column, $post_id ) {
	global $post;
	the_post_thumbnail('thumbnail', array('class' => 'column-img'));
}

//
// Team Title and Caption
//

add_action("admin_init", "vntd_slider_title_settings");   

if(!function_exists('vntd_slider_title_settings')) {

	function vntd_slider_title_settings(){
	    add_meta_box("slider_content", "Slide Content", "vntd_slider_content", "vntd_slider", "normal", "high");
	    add_meta_box("slider_settings", "Slide Settings", "vntd_slider_settings", "vntd_slider", "normal", "high");
	}   
	
	function vntd_slider_content(){
	        global $post;
	        if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return $post_id;	        
	        $custom = get_post_custom($post->ID);
	        
	        $slide_heading = $slide_secondary_heading = $slide_text = $button1_label = $button1_url = $button2_label = $button2_url = '';	        
	        
	        if(isset($custom["slide_heading"][0])) $slide_heading = $custom["slide_heading"][0];
	        if(isset($custom["slide_secondary_heading"][0])) $slide_secondary_heading = $custom["slide_secondary_heading"][0];
	        if(isset($custom["slide_text"][0])) $slide_text = $custom["slide_text"][0];
			if(isset($custom["button1_label"][0])) $button1_label = $custom["button1_label"][0];
			if(isset($custom["button1_url"][0])) $button1_url = $custom["button1_url"][0];

			if(isset($custom["button2_label"][0])) $button2_label = $custom["button2_label"][0];
			if(isset($custom["button2_url"][0])) $button2_url = $custom["button2_url"][0];

			
	?>	    
		<div class="metabox-options form-table fullwidth-metabox image-upload-dep">
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Slide Main Heading', 'waxom') ?>:</h6>
				<?php if(!$slide_heading) $slide_heading = "My Main Slide Heading"; ?>
				<input type="text" name="slide_heading" value="<?php echo esc_textarea($slide_heading); ?>">
			</div>	
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Slide Secondary Heading: <span>(above the Main Heading)</span>', 'waxom') ?></h6>
				<input type="text" name="slide_secondary_heading" placeholder="<?php esc_html_e("My Secondary Slide Heading", "waxom"); ?>" value="<?php echo esc_textarea($slide_secondary_heading); ?>">
			</div>	
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Slide Text Content', 'waxom') ?>:</h6>
				<?php if(!$slide_text) $slide_text = "My Slide Text Content"; ?>
				<textarea name="slide_text" placeholder="<?php esc_html_e('My Slide Content', 'waxom') ?>"><?php echo esc_textarea($slide_text); ?></textarea>
			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 1 Label', 'waxom') ?>:</h6>
				<?php if(!$button1_label) $button1_label = "Button Label"; ?>
				<input type="text" name="button1_label" value="<?php echo esc_textarea($button1_label); ?>">
			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 1 URL', 'waxom') ?>:</h6>
				<?php if(!$button1_url) $button1_url = "#"; ?>
				<input type="text" name="button1_url" value="<?php echo esc_url($button1_url); ?>">
			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 2 Label', 'waxom') ?>:</h6>
				<input type="text" name="button2_label" value="<?php echo esc_textarea($button2_label); ?>">
			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 2 URL', 'waxom') ?>:</h6>
				<input type="text" name="button2_url" value="<?php echo esc_url($button2_url); ?>">
			</div>
			
		</div>
	<?php
	}
	
	function vntd_slider_settings(){
	        global $post;
	        if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return $post_id;
	        $custom = get_post_custom($post->ID);
	        
	        $heading_weight = $heading_texttransform = $heading_size = $heading_weight = $text_color = $content_align = $button1_color = $button1_style = $button2_color = $button1_color_hover = $button2_color_hover = $button2_style = $slide_overlay = $slide_height = $offset_top = $fullscreen = '';
	        
	        if(isset($custom["heading_weight"][0])) $heading_weight = $custom["heading_weight"][0];
	        if(isset($custom["heading_texttransform"][0])) $heading_texttransform = $custom["heading_texttransform"][0];
	        if(isset($custom["heading_size"][0])) $heading_size = $custom["heading_size"][0];
	        if(isset($custom["heading_weight"][0])) $heading_weight = $custom["heading_weight"][0];
	        
	        if(isset($custom["text_color"][0])) $text_color = $custom["text_color"][0];
	        if(isset($custom["content_align"][0])) $content_align = $custom["content_align"][0];
	        
	        if(isset($custom["button1_color"][0])) $button1_color = $custom["button1_color"][0];
	        if(isset($custom["button1_color_hover"][0])) $button1_color_hover = $custom["button1_color_hover"][0];
	        if(isset($custom["button1_style"][0])) $button1_style = $custom["button1_style"][0];
	        if(isset($custom["button2_color"][0])) $button2_color = $custom["button2_color"][0];
	        if(isset($custom["button2_color_hover"][0])) $button2_color_hover = $custom["button2_color_hover"][0];
	        if(isset($custom["button2_style"][0])) $button2_style = $custom["button2_style"][0];	
	        
	        if(isset($custom["slide_overlay"][0])) $slide_overlay = $custom["slide_overlay"][0];
	        if(isset($custom["offset_top"][0])) $offset_top = $custom["offset_top"][0];
	?>
	
		<div class="metabox-options form-table fullwidth-metabox image-upload-dep">
			
			<h2 class="metabox-title">Basic Settings</h2>
			<div class="metabox-option">
				<h6><?php esc_html_e('Slide Overlay', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_slide_overlay = array(
					'None' => "none",
					'Dark' => "dark",
					'Darker' => "darker"
				);
				
				waxom_create_dropdown('slide_overlay',$arr_slide_overlay,$slide_overlay);
				
				?>

			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Content Align', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_content_align = array(
					'Center' => "center",
					'Left' => "left",
					'Right' => "right"
				);
				
				waxom_create_dropdown('content_align',$arr_content_align,$content_align);
				
				?>

			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Text Color', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_text_color = array(
					'White' => "white",
					'Dark' => "dark"
				);
				
				waxom_create_dropdown('text_color',$arr_text_color,$text_color);
				
				?>
	
			</div>
			
			<h2 class="metabox-title">Advanced Settings</h2>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Main Heading Font Size', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_heading_size = array(
					'48' => 48,
					'52' => 52,
					'56' => 56,
					'60' => 60,
					'64' => 64,
					'68' => 68,
					'72' => 72,
					'76' => 76,
					'80' => 80,
					'88' => 88
				);
				
				if(!$heading_size) $heading_size = 56;
				
				waxom_create_dropdown('heading_size',$arr_heading_size,$heading_size);
				
				?>

			</div>
			
			<!--<div class="metabox-option">
				<h6><?php esc_html_e('Heading Text Transform', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_heading_texttransform = array(
					'Normal' => "normal",
					'Uppercase' => "uppercase"
									
				);
				
				waxom_create_dropdown('heading_texttransform',$arr_heading_texttransform,$heading_texttransform);
				
				?>

			</div>-->
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 1 Color', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_button1_color = array(					
					'Accent' => "accent",
					'Accent 2' => "accent2",
					'Accent 3' => "accent3",
					'Accent 4' => "accent4",
					'White' => "white",
				);
				
				if(!$button1_color) $button1_color = 'accent3';
				
				waxom_create_dropdown('button1_color',$arr_button1_color,$button1_color);
				
				?>

			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 1 Hover Color', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_button1_color_hover = array(
					'Accent' => "accent",
					'Accent 2' => "accent2",
					'Accent 3' => "accent3",
					'Accent 4' => "accent4",
					'White' => "white",
				);
				
				if(!$button1_color_hover) $button1_color_hover = 'white';
				
				waxom_create_dropdown('button1_color_hover',$arr_button1_color_hover,$button1_color_hover);
				
				?>

			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 1 Style', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_button1_style = array(
					'Default' => "default",
					'Stroke (Outline)' => "stroke",			
				);
				
				waxom_create_dropdown('button1_style',$arr_button1_style,$button1_style);
				
				?>

			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 2 Color', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_button2_color = array(
					'Accent' => "accent",
					'Accent 2' => "accent2",
					'Accent 3' => "accent3",
					'Accent 4' => "accent4",
					'White' => "white",
				);
				
				if(!$button2_color) $button2_color = 'white';
				
				waxom_create_dropdown('button2_color',$arr_button2_color,$button2_color);
				
				?>

			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 2 Hover Color', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_button2_color_hover = array(
					'Accent' => "accent",
					'Accent 2' => "accent2",
					'Accent 3' => "accent3",
					'Accent 4' => "accent4",
					'White' => "white",
				);
				
				if(!$button2_color_hover) $button2_color_hover = 'white';
				
				waxom_create_dropdown('button2_color_hover',$arr_button2_color_hover,$button2_color_hover);
				
				?>

			</div>
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Button 2 Style', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_button2_style = array(
					'Default' => "default",
					'Stroke (Outline)' => "stroke",			
				);
				
				if(!$button2_style) $button2_style = 'stroke';
				
				waxom_create_dropdown('button2_style',$arr_button2_style,$button2_style);
				
				?>

			</div>
			
			<div class="metabox-separator"></div>
			
			
			<div class="metabox-option">
				<h6><?php esc_html_e('Content Offset Top', 'waxom') ?>:</h6>
				
				<?php
				
				$arr_offset_top = array(
					'0' => 0,
					'10' => 10,
					'20' => 20,
					'30' => 30,
					'40' => 40,
					'50' => 50,
					'60' => 60,
					'70' => 70
				);
				
				if(!$offset_top) $offset_top = 0;
				
				waxom_create_dropdown('offset_top',$arr_offset_top,$offset_top);
				
				?>

			</div>
				
			
		</div>
	
	<?php
	
	}
    
}  

	
	
// Save Slide
	
add_action('save_post', 'waxom_save_slider_meta'); 

function waxom_save_slider_meta(){
    global $post;  	
	
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ){
		return $post_id;
	}else{
	
		$post_metas = array('slide_heading','slide_secondary_heading','slide_text','button1_label','button1_url','button2_label','button2_url', 'slide_height', 'content_align', 'heading_weight', 'heading_texttransform', 'heading_size', 'text_color', 'button1_color', 'button1_color_hover', 'button1_style', 'button2_color', 'button2_color_hover', 'button2_style', 'slide_overlay','offset_top','fullscreen');
		
		foreach($post_metas as $post_meta) {
			if(isset($_POST[$post_meta])) update_post_meta($post->ID, $post_meta, $_POST[$post_meta]);
		}
    }

}

function vntd_slider_categories() {
	global $post;
	
	$terms = wp_get_object_terms($post->ID, "member-position");
	
	if($terms) {
		foreach ( $terms as $term ) {
			echo esc_textarea($term->name);
			if(end($terms) !== $term){
				echo ", ";
			}
		}
	}
}

function vntd_slider_item_class(){
	
	global $post;
	$output = '';
    $terms = wp_get_object_terms($post->ID, "member-position");
	foreach ( $terms as $term ) {
		$output .= $term->slug . " ";
	}		
	
	return $output;
	
}