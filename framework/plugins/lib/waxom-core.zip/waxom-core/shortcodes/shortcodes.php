<?php

define('WAXOM_SHORTCODES', plugin_dir_path( __FILE__ ));

// Add TinyMCE Button

add_action('init', 'waxom_add_tinymce_button');

function waxom_add_tinymce_button() {
	//if(strstr($_SERVER['REQUEST_URI'], 'wp-admin/post-new.php') || strstr($_SERVER['REQUEST_URI'], 'wp-admin/post.php')) {
			add_filter('mce_external_plugins', 'waxom_add_tinymce_plugin');  
			add_filter('mce_buttons', 'waxom_register_tinymce_button');  
	//}
}    

function waxom_register_tinymce_button($buttons) {
   array_push($buttons, 'separator', "waxom_shortcodes_button"); 
   //array_push($buttons, "waxom_visual_button"); 
   return $buttons;
}  

function waxom_add_tinymce_plugin($plugin_array) {  
   $plugin_array['waxom_shortcodes_button'] = plugins_url() . '/waxom-core/shortcodes/tinymce/tinymce-quick-shortcodes.js';
   //$plugin_array['waxom_visual_button'] = get_template_directory_uri() . '/framework/shortcodes/tinymce/tinymce-visual-shortcodes.js';
   return $plugin_array;  
}

// Load complex shortcodes

include_once( WAXOM_SHORTCODES . '/lib/google-map.php');
include_once( WAXOM_SHORTCODES . '/lib/blog.php');
include_once( WAXOM_SHORTCODES . '/lib/carousel-portfolio.php');
include_once( WAXOM_SHORTCODES . '/lib/carousel-blog.php');
include_once( WAXOM_SHORTCODES . '/lib/carousel-team.php');
include_once( WAXOM_SHORTCODES . '/lib/carousel-testimonials.php');
include_once( WAXOM_SHORTCODES . '/lib/carousel-logos.php');
include_once( WAXOM_SHORTCODES . '/lib/button.php');
include_once( WAXOM_SHORTCODES . '/lib/counter.php');
include_once( WAXOM_SHORTCODES . '/lib/contact-block.php');
include_once( WAXOM_SHORTCODES . '/lib/contact-form.php');
include_once( WAXOM_SHORTCODES . '/lib/call-to-action.php');
include_once( WAXOM_SHORTCODES . '/lib/fullscreen-slider.php');
include_once( WAXOM_SHORTCODES . '/lib/icon.php');
include_once( WAXOM_SHORTCODES . '/lib/icon-box.php');
include_once( WAXOM_SHORTCODES . '/lib/list.php');
include_once( WAXOM_SHORTCODES . '/lib/grid-portfolio.php');
include_once( WAXOM_SHORTCODES . '/lib/grid-team.php');
include_once( WAXOM_SHORTCODES . '/lib/hero-section.php');
include_once( WAXOM_SHORTCODES . '/lib/portfolio-details.php');
include_once( WAXOM_SHORTCODES . '/lib/pricing-box.php');
include_once( WAXOM_SHORTCODES . '/lib/section.php');
include_once( WAXOM_SHORTCODES . '/lib/social-icons.php');
include_once( WAXOM_SHORTCODES . '/lib/veented-slider.php');
include_once( WAXOM_SHORTCODES . '/lib/video-lightbox.php');


// - - -
// Function removing extra br and p tags
// - - -

function waxom_do_shortcode($content) {
    $array = array('<p>[' => '[','<br />[' => '[', '<br>[' => '[', ']</p>' => ']', ']<br />' => ']', ']<br>' => ']');
    $content = strtr($content, $array);
    return do_shortcode($content);
}

// - - - - - - - - - -
// Separator
// - - - - - - - - - -

function waxom_separator($atts, $content=null){
	extract(shortcode_atts(array(
		"type" => '',
		"style" => 'default',
		"label" => '',
		"align" => 'center',
		"space_height" => ''			
	), $atts));
	
	$separator_class = $separator_label = '';
	
	if($type != "space") {
		if($style != "default") {
			$separator_class .= ' separator-shadow';
		}
		if($type == "fullwidth") {
			$separator_class .= ' separator-fullwidth';
		}
		if($label) {
			$separator_label = '<div>'.$label.'</div>';
			$separator_class .= ' separator-text-align-'.$align;
		}
		$output = '<div class="separator'.esc_attr($separator_class).'">'.esc_html($separator_label).'</div>';
	} else {
		if($space_height != 40) {
			$space_style = 'style="height:'.esc_attr($space_height).'px;"';
		}
		$output = '<div class="white-space"'.esc_attr($space_style).'></div>';
	}
	
	
	return $output;
	
}
remove_shortcode('separator');
add_shortcode('separator', 'waxom_separator');

function waxom_spacer($atts, $content=null){
	extract(shortcode_atts(array(
		"height" => '40'			
	), $atts));
		
	if($height != 40) {
		$height_style = 'style="height:'.esc_attr($height).'px;"';
	}
	
	return '<div class="spacer"'.esc_attr($height_style).'></div>';	
	
}
remove_shortcode('spacer');
add_shortcode('spacer', 'waxom_spacer');


// - - - - - - - - - -
// Typography
// - - - - - - - - - -

function waxom_heading($atts, $content=null) {
	extract(shortcode_atts(array(
		"title" => '',
		"subtitle" => '',
		"animated" => 'yes',
		"margin_bottom" => '30',
		"font"			=> '',
		"text_align"	=> 'center'
	), $atts));
	
	$animation_class = $animation_data = $margin_style = $font_class = '';
	
	if($animated != 'no') {
		$animation_class = ' animated';
		$animation_data = ' data-animation="fadeIn" data-animation-delay="100"';
	}
	$margin_bottom = str_replace('px','',$margin_bottom);
	if($margin_bottom != 30) {		
		$margin_style = ' style="margin-bottom:'.esc_attr($margin_bottom).'px;"';
	}	
	
	if($font == 'secondary') {
		$font_class = ' font-secondary';
	}
	
	$return = '<div class="vntd-special-heading special-heading-align-'.esc_attr($text_align).'"'.$margin_style.'><h1 class="'.esc_attr($font_class).esc_attr($animation_class).'" '.$animation_data.'>'.$title.'</h1>';
	
	if($subtitle) {
		$return .= '<h6 class="subtitle '.esc_attr($animation_class).'" '.$animation_data.'>'.$subtitle.'</h6>';
	}
	$return .= '</div>';
	return $return;

}

function waxom_callout_box($atts, $content=null) {
	extract(shortcode_atts(array(
		"title" => '',
		"subtitle" => ''
	), $atts));
	
	$return = '<div class="vntd-callout-box bs-callout bs-callout-north"><h2 class="colored uppercase font-primary">'.$title.'</h2><p>'.$subtitle.'</p></div>';

	return $return;

}


function waxom_highlight($atts, $content=null) {
	extract(shortcode_atts(array("color" => '',"bgcolor" => ''), $atts));
	
	if($color || $bgcolor) {
		$color_class = 'style="background-color:'.esc_attr($bgcolor).';color:'.esc_attr($color).'"';
	}	
	
	return '<span class="vntd-highlight vntd-accent-bgcolor"'.$color_class.'>'.$content.'</span>';
}

function waxom_alternative($atts, $content=null) {
	
	return '<div class="vntd-alternative-section">'.$content.'</div>';
}

function waxom_dropcap1($atts, $content=null) {
	extract(shortcode_atts(array("color" => '',"style" => 'style1'), $atts));
	
	$color_class = '';
	
	if($color && $color != 'accent') {
		if($style == 'style1') {
			$color_class = 'style="color:'.esc_attr($color).'"';
		} else {
			$color_class = 'style="background-color:'.esc_attr($color).'"';
		}
	}
	
	return '<span class="vntd-dropcap dropcap-'.esc_attr($style).'"'.$color_class.'>'.$content.'</span>';
}

function waxom_quote($atts, $content=null) {
	extract(shortcode_atts(array("style" => 'style1', 'author' => ''), $atts));
	
	return '<blockquote class="blockquote-'.esc_attr($style).' vntd-custom-blockquote"><div class="blockquote-content">'.$content.'</div><div class="blockquote-author">'.$author.'</div></blockquote>';
}

function waxom_tooltip($atts, $content=null) {
	extract(shortcode_atts(array("style" => 'style1', "label" => 'Your text'), $atts));
	
	$length = strlen($label)*8;
	$lengthHalf = $length/2;
	return '<span class="vntd-tooltip tooltip-'.esc_attr($style).'">'.$content.'<span class="vntd-tooltip-label" style="width:'.$length.'px;margin-left:-'.$lengthHalf.'px;">'.$label.'</span></span>';
}

function waxom_text($atts, $content=null) {
	extract(shortcode_atts(array("size" => '20'), $atts));
	
	return '<p class="vntd-text" style="font-size:'.str_replace('px','',esc_attr($size)).'px;">'.$content.'</p>';
}

remove_shortcode('tooltip');
remove_shortcode('highlight');
remove_shortcode('alternative');
remove_shortcode('dropcap1');
remove_shortcode('dropcap2');
remove_shortcode('special_heading');
remove_shortcode('quote');
remove_shortcode('callout_box');
remove_shortcode('text');

add_shortcode('tooltip', 'waxom_tooltip');
add_shortcode('special_heading', 'waxom_heading');
add_shortcode('dropcap', 'waxom_dropcap1');
add_shortcode('alternative', 'waxom_alternative');
add_shortcode('highlight', 'waxom_highlight');
add_shortcode('quote', 'waxom_quote');
add_shortcode('tooltip', 'waxom_tooltip');
add_shortcode('callout_box', 'waxom_callout_box');
add_shortcode('text', 'waxom_text');