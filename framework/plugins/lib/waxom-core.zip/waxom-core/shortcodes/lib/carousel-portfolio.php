<?php

// Recent Work Shortcode


function waxom_portfolio_carousel($atts, $content = null) {
	extract(shortcode_atts(array(
		"cats" => '',
		"posts_nr" => '',
		"thumb_style" => 'title_category',
		"hover_style" => 'simple',
		"cols" => 3,
		"thumb_space" => 'yes',
		"autoplay" => 'true',
		"autoplay_timeout" => 7000,
		"dots" => "true",
		"nav" => "false",
		"nav_position" => "top_right",
		"carousel_title" => '',
		"love" => 'yes'
	), $atts));
	
	wp_enqueue_script('magnific-popup', '', '', '', true);
	wp_enqueue_style('magnific-popup');
	
	wp_enqueue_script('owl-carousel', '', '', '', true);
	wp_enqueue_style('owl-carousel');

	ob_start();
	
	$margin = 30;
	
	if($thumb_space == 'no') {
		$margin = 0;
	}
	
	echo '<div class="vntd-carousel-holder">';
	
	if($carousel_title) {
		echo '<div class="vntd-carousel-title"><h3>'.$carousel_title.'</h3></div>';
	}

	echo '<div class="vntd-portfolio-carousel carousel-gallery vntd-carousel portfolio-style portfolio-'.$hover_style.' portfolio-'.$thumb_style.' carousel-nav-'.$nav.' nav-position-'.$nav_position.'" data-cols="'.$cols.'" data-autoplay="'.$autoplay.'" data-autoplay-timeout="'.esc_attr($autoplay_timeout).'" data-margin="'.$margin.'" data-dots="'.$dots.'" data-nav="'.$nav.'">';

	$size = 'vntd-portfolio-square';
				
	wp_reset_postdata();
	
	$args = array(
		'posts_per_page' => $posts_nr,
		'project-type'		=> $cats,
		'post_type' => 'portfolio',
		'orderby'	=> 'slug'
	);
	
	$the_query = new WP_Query($args); 
	
	if ($the_query->have_posts()) : while ($the_query->have_posts()) : $the_query->the_post();
	
	$img_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), $size);
	$thumb_url = $img_url[0];
	
	$img_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'large');
	$big_thumb_url = $img_url[0];
	
	$post_link = get_permalink();
	
	$post_link_type = get_post_meta(get_the_ID(),'link_type',TRUE);
	
	if($post_link_type == 'external' && get_post_meta(get_the_ID(),'portfolio_external_url',TRUE)) {
		$data_content = '';
		$ajax_class = '';
		$post_link = get_post_meta(get_the_ID(),'portfolio_external_url',TRUE);
	}
	
	$lightbox_content_class = $item_lightbox_class = '';
	if($post_link_type != 'link' && $post_link_type != 'external') {
		$item_lightbox_class = ' portfolio-item-lightbox';
		$lightbox_content_class = ' cbp-portfolio-lightbox';
	}
	
	?>
		
		<!-- Item -->
		<div class="item carousel-item">
			
			<div class="item-inner">
			
				<a href="<?php echo esc_url($post_link); ?>" class="work-image<?php echo esc_attr($lightbox_content_class); ?>">

					<img src="<?php echo esc_url($thumb_url) ?>" alt="<?php the_title(); ?>">

					<div class="portfolio-item-overlay">
						
						<?php if($hover_style != "bottom") { ?>
						<div class="portfolio-overlay-icons">
							<span class="overlay-icon overlay-icon-link" href="<?php echo esc_url($post_link); ?>"><i class="fa fa-link"></i></span>
							<span class="overlay-icon overlay-icon-zoom carousel-lightbox" href="<?php echo esc_url($big_thumb_url) ?>"><i class="fa fa-search"></i></span>
						</div>
						<?php } ?>
						
						<h3 class="portfolio-overlay-title">
							<?php the_title(); ?>
						</h3>
						
						<div class="portfolio-overlay-cats"><?php waxom_portfolio_overlay_categories(); ?></div>
						<?php if(get_post_meta(get_the_ID(),'portfolio_post_excerpt',TRUE)) { ?>
						<p class="portfolio-overlay-excerpt">
							<?php echo esc_textarea(get_post_meta(get_the_ID(),'portfolio_post_excerpt',TRUE)); ?>
						</p>
						<?php } ?>
					</div>

				</a>

			</div>
			
			<?php if($thumb_style && $thumb_style != "simple") { ?>
			<div class="item-outer">
				<h3 class="portfolio-outer-title">
					<a href="<?php echo esc_url($post_link); ?>" class="portfolio-outer-link<?php echo esc_attr($lightbox_content_class); ?>"><?php the_title(); ?></a>
				</h3>
				<div class="portfolio-outer-cats"><?php waxom_portfolio_overlay_categories(); ?></div>
				<?php if(get_post_meta(get_the_ID(),'portfolio_post_excerpt',TRUE)) { ?>
				<p class="portfolio-outer-excerpt">
					<?php echo get_post_meta(get_the_ID(),'portfolio_post_excerpt',TRUE); ?>
				</p>
				<?php } 
				
				if($love == "yes" && $thumb_style == "title_category") waxom_love_button();
				
				if($thumb_style == "title_excerpt_more") { ?>
				<div class="portfolio-view-more btn btn-dark"><a href="<?php echo esc_url($post_link); ?>"><?php esc_html_e('View More', 'waxom'); ?></a></div>
				
				<?php }	?>
			</div>
			<?php } ?>
			
		</div>
		<!-- End Item -->
	
	<?php
	
	
	endwhile; endif; wp_reset_postdata();		
	
	echo '</div></div>';
	
	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('portfolio_carousel');
add_shortcode('portfolio_carousel', 'waxom_portfolio_carousel');