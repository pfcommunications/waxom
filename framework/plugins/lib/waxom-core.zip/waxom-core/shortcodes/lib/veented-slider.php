<?php

// Blog Posts Carousel

function veented_slider($atts, $content = null) {
	extract(shortcode_atts(array(
		"cats" => '',
		"height" => 'fullscreen',
		"height_custom" => '',
		"offset" => '',
		"autoplay" => '7000',
		"scroll_button" => 'no',
		"scroll_button_label" => 'View More',
		"slider_effect" => 'slide'
	), $atts));
	
	wp_enqueue_script('swiper', '', '', '', true);
	wp_enqueue_style('swiperCSS');	
	
	$fullscreen = 0;
	$fullscreen_class = '';
	if($height != 'custom') $fullscreen_class = ' veented-slider-fullscreen';
	
	$random_id = rand(1,9999);

	$scroll_class = '';
	if($scroll_button == 'yes') {
		$scroll_class = ' veented-slider-with-scroll';
	}

	ob_start();
	
	?>
    
    <div id="veented-slider-<?php echo $random_id; ?>" class="veented-slider-holder<?php echo $fullscreen_class.$scroll_class; ?>" data-slider-autoplay="<?php echo esc_attr($autoplay); ?>" data-slider-effect="<?php echo esc_attr($slider_effect); ?>">
	
		<div class="veented-slider-loader">
			<div class="spinner">
			  <div class="dot1"></div>
			  <div class="dot2"></div>
			</div>
		</div>
		
		<div class="veented-slider swiper-containers">
		
			<div class="veented-slider-inner swiper-wrapper">
			
				<?php
				
				wp_reset_postdata();						

				$args = array(
					//'posts_per_page' 	=> $posts_nr,
					'post_type' 		=> 'vntd_slider',
					'slide-locations' 	=> $cats
				);				
				
				$the_query = new WP_Query($args);
				$i = 0;
				
				if ($the_query->have_posts()) : while ($the_query->have_posts()) : $the_query->the_post();
				$i++;

				// Background Image
				
				$img_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
				
				// Animation
				
				$animated_class = '';
				
				if(get_post_meta(get_the_ID(),"animation",TRUE) != 'no') {
					$animated_class = ' animated animatedSlider';
				}
				
				?>
				
				<div class="swiper-slide veented-slide swiper-lazy veented-slide-<?php echo $i; ?> veented-slide-align-<?php echo get_post_meta(get_the_ID(),"content_align",TRUE); ?> veented-slide-color-<?php echo get_post_meta(get_the_ID(),"text_color",TRUE); ?> veented-slide-heading-transform-<?php echo get_post_meta(get_the_ID(),"heading_texttransform",TRUE); ?> veented-slide-heading-weight-<?php echo get_post_meta(get_the_ID(),"heading_weight",TRUE); ?> veented-slide-overlay-<?php echo get_post_meta(get_the_ID(),"slide_overlay",TRUE); ?>" style="background-image:url(<?php echo esc_url($img_url[0]); ?>);" data-background="<?php echo esc_url($img_url[0]); ?>">
				
					<div class="inner">
						<div class="veented-slide-inner">
							<?php
							
							if(get_post_meta(get_the_ID(),"slide_secondary_heading",TRUE)) {
								?>
								<h3 class="veented-slide-secondary-heading<?php echo $animated_class; ?>"><?php echo esc_textarea(get_post_meta(get_the_ID(),"slide_secondary_heading",TRUE)); ?></h3>
								<?php
							}
							
							
							$heading_style = '';
							if(get_post_meta(get_the_ID(),"heading_size",TRUE) != 56) $heading_style = 'style="font-size:'.esc_attr(get_post_meta(get_the_ID(),"heading_size",TRUE)).'px;"';
							
							?>
							<h2 class="veented-slide-heading<?php echo $animated_class; ?>"<?php echo $heading_style; ?>> <?php echo esc_textarea(get_post_meta(get_the_ID(),"slide_heading",TRUE)); ?></h2>
							<?php if(get_post_meta(get_the_ID(),"slide_text",TRUE)) { ?>
							<p class="veented-slide-paragraph<?php echo $animated_class; ?>"><?php echo str_replace("&lt;br&gt;", "<br>",esc_textarea(get_post_meta(get_the_ID(),"slide_text",TRUE))); ?></p>
							<?php }
							
							if(get_post_meta(get_the_ID(),"button1_label",TRUE) || get_post_meta(get_the_ID(),"button2_label",TRUE)) { 
							
								echo '<div class="veented-slide-buttons'.$animated_class.'">';
								if(get_post_meta(get_the_ID(),"button1_label",TRUE)) {
								
									$button1_color = 'accent';
									$button1_color = esc_attr(get_post_meta(get_the_ID(),"button1_color",TRUE));
									
									$button1_class = '';
									if(get_post_meta(get_the_ID(),"button1_style",TRUE) == 'stroke') $button1_class = ' btn-style-stroke';
									
									$button1_color_hover = ' btn-hover-'.esc_attr(get_post_meta(get_the_ID(),"button1_color_hover",TRUE));
									
									$button1_url = esc_url(get_post_meta(get_the_ID(),"button1_url",TRUE));
									
									if (strpos($button1_url, '#') !== false) {
									    $button1_class .= ' scroll';
									}

									echo '<a class="btn btn-'.$button1_color.$button1_class.$button1_color_hover.' veented-slide-button1" href="'. $button1_url .'">'.esc_textarea(get_post_meta(get_the_ID(),"button1_label",TRUE)).'</a>';
									
								}
								if(get_post_meta(get_the_ID(),"button2_label",TRUE)) {
									$button2_color = 'white';
									$button2_color = esc_attr(get_post_meta(get_the_ID(),"button2_color",TRUE));
									
									$button2_class = '';
									if(get_post_meta(get_the_ID(),"button2_style",TRUE) != 'default') $button2_class = ' btn-style-stroke';
									
									$button2_color_hover = '';
									
									$button2_color_hover = ' btn-hover-'.esc_attr(get_post_meta(get_the_ID(),"button2_color_hover",TRUE));
									
									$button2_url = esc_url(get_post_meta(get_the_ID(),"button2_url",TRUE));
									
									if (strpos($button2_url, '#') !== false) {
									    $button2_class .= ' scroll';
									}
									
									echo '<a class="btn '.$button2_class.' btn-'.$button2_color.$button2_color_hover.' veented-slide-button2" href="'. $button2_url .'">'.esc_textarea(get_post_meta(get_the_ID(),"button2_label",TRUE)).'</a>';
								}
								echo '</div>';
							} 
							
							?>
						</div>
						
					</div>
				
				</div>
									
				<?php	
					 
				endwhile; endif; wp_reset_postdata();

				if($height_custom > 0 && $height == 'custom' || $offset != 0) {
					$height_custom = str_replace('px','',$height_custom);
					echo '<style type="text/css">';
					if($height_custom > 0 && $height == 'custom') {
						echo '#veented-slider-'.$random_id.' { height: '.esc_attr($height_custom).'px; }';	
					}
					if($offset != 0) {
						echo '#veented-slider-'.$random_id.' .inner { padding-top: '.esc_attr($offset).'px; }';
					}
					echo '</style>';			
				}			
				
				?>    
		
			</div>
		
			<!-- Slider Pagination -->
		
			<div class="veented-slider-pagination swiper-pagination"></div>
			
			<!-- Slider Arrows -->
			
			<div class="swiper-button-next"><i class="fa fa-angle-right"></i></div>
			<div class="swiper-button-prev"><i class="fa fa-angle-left"></i></div>

			<?php

			if($scroll_button == 'yes') {
				echo '<div class="veented-slider-scroll-button-holder"><a href="#second" class="scroll veented-slider-scroll-button"><span class="vntd-mouse-dot"></span></a></div>';
			}

			?>
		
		</div>
	
	</div>
	
	<?php
	
	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('veented_slider');
add_shortcode('veented_slider', 'veented_slider');