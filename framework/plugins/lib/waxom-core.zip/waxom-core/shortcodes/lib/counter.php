<?php

// Counter Shortcode Processing

function waxom_counter($atts, $content=null){

	$defaultFont = 'fontawesome';
	$defaultIconClass = 'fa fa-info-circle';
	
	extract(shortcode_atts(array(
		"title" => 'Days',
		"number" => '100',
		"color" => 'accent',
		"color_custom" => '',
		"icon" => 'heart-o',
		"icon_type" => $defaultFont,
		"icon_fontawesome" => $defaultIconClass,
		"icon_typicons" => '',
		"icon_openiconic" => '',
		"icon_entypo" => '',
		"icon_linecons" => '',
		"style" => 'default'
	), $atts));
	
	// Icon related
	
	$icon = str_replace('fa-','',$icon);
	vc_icon_element_fonts_enqueue( $icon_type );	
	$iconClass = isset( ${"icon_" . $icon_type} ) ? ${"icon_" . $icon_type} : $defaultIconClass;
	
	// End Icon related
	
	$rand_id = rand(1,1000);
	
	$extra_style = '';
	
	$return = '<div id="counter-'.$rand_id.'" class="vntd-counter counter-color-'.$color.' counter-style-'.$style.'" data-perc="'.$number.'"><div class="counter-icon"><i class="'.$iconClass.'"'.$extra_style.'></i></div>';
	
	$return .= '<div class="counter-value"><div class="counter-number"'.$extra_style.'>0</div></div>';
	
	$return .= '<div class="counter-title"><h6'.$extra_style.'>'.$title.'</h6></div>';
	
	$return .= '</div>';
	
	if($color == 'custom' && $color_custom) {
		$return .= '<style type="text/css">.counter-color-dark,
		#counter-'.$rand_id.' h6,
		#counter-'.$rand_id.' .counter-number,
		#counter-'.$rand_id.' .counter-icon {
			color: '.$color_custom.' !important;
		}
		
		#counter-'.$rand_id.' .counter-number:after,
		#counter-'.$rand_id.' .counter-number:before,
		#counter-'.$rand_id.' .counter-value {
			border-color: '.$color_custom.' !important;
		}
	}</style>';
	}
	
	return $return;
}
remove_shortcode('counter');
add_shortcode('counter', 'waxom_counter');