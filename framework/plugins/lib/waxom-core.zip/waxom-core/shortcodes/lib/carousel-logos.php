<?php

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//		Testimonials Carousel
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function waxom_logos($atts, $content = null) {
	extract(shortcode_atts(array(
		"images" => '',
		"onclick" => '',
		"custom_links" => '',
		"cols" => 4,
		"autoplay" => 'true',
		"autoplay_timeout" => 7000,
		"dots" => "true",
		"nav" => "false",
		"nav_position" => "bottom",
		"carousel_title" => '',
		"overlay" => 'no',
		"logos_height" => 'regular',
		"logos_style" => 'regular'
	), $atts));
	

	wp_enqueue_script('owl-carousel', '', '', '', true);
	wp_enqueue_style('owl-carousel');

	
	ob_start();	
	
	$link_href = '';
	
	if($onclick == 'custom_link') {
		$custom_links = explode(',',$custom_links);
	}
					 			
	$images = explode( ',', $images );
	$i = - 1;
	
	$overlay_class = '';
	
	if($overlay == 'no') {
		$overlay_class = ' logos-overlay-'.$overlay;
	}
	
	echo '<div class="vntd-carousel-holder'.$overlay_class.'">';
		
		if($carousel_title) {
			echo '<div class="vntd-carousel-title"><h2>'.$carousel_title.'</h2></div>';
		}
		
		echo '<div class="vntd-carousel vntd-logos-carousel vntd-logos logos-style-'.esc_attr($logos_style).' logos-height-'.esc_attr($logos_height).' carousel-nav-'.esc_attr($nav).' nav-position-'.esc_attr($nav_position).'" data-cols="'.esc_attr($cols).'" data-autoplay="'.esc_attr($autoplay).'" data-autoplay-timeout="'.esc_attr($autoplay_timeout).'" data-margin="30" data-dots="'.esc_attr($dots).'" data-nav="'.esc_attr($nav).'">';	
			
		foreach ( $images as $attach_id ) {
			$i ++;
			$link_href = '';
			if($onclick == 'custom_link') {
				$link_href = ' target="_blank" href="'.esc_url($custom_links[$i]).'"';
			}
			$img = wp_get_attachment_image_src($attach_id, 'full');
			
			?>
			<a <?php if($link_href) echo $link_href; ?> class="item logo-item">
				<img src="<?php echo esc_url($img[0]); ?>" alt>
			</a>				
			<?php

		}
			
	echo '</div></div>';
	
	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('logos_carousel');
add_shortcode('logos_carousel', 'waxom_logos');