<?php

// Blog Posts Carousel

function waxom_hero_section($atts, $content = null) {
	extract(shortcode_atts(array(
		"cats" => '',
		"height" => 'fullscreen',
		"height_custom" => '',
		"offset" => '',
		"autoplay" => '7000',
		"scroll_button" => 'no',
		"scroll_button_label" => 'View More',
		"media_type" => 'images',
		"youtube_url" => 'https://www.youtube.com/watch?v=lMJXxhRFO1k',
		"images" => '',
		"img_size" => 'full',
		"slider_effect" => 'fade',
		"heading" => '',
		"subheading" => 'Secondary Heading',
		"title" => 'My Hero Section',
		"subtitle" => 'Hero Subtitle',
		"bg_overlay" => 'none',
		"arrow_navigation" => 'yes',
		"bullet_navigation" => 'no',
		"button1_label" => 'Button Text',
		"button1_style" => 'default',
		"button1_color" => 'accent',
		"button1_url" => '#second',
		"button2_label" => 'Button 2 Text',
		"button2_style" => 'stroke',
		"button2_color" => 'white',
		"button2_url" => '#',
		"video_autoplay" => 'true',
		"video_controls" => 'false',
		"video_mute" => 'true'
	), $atts));
	
	if($media_type == "images") {
		wp_enqueue_script('swiper', '', '', '', true);
		wp_enqueue_style('swiperCSS');
	}	
	
	$fullscreen = 0;
	$fullscreen_class = '';
	if($height != 'custom') $fullscreen_class = ' veented-slider-fullscreen';
	
	$random_id = rand(1,9999);

	$scroll_class = '';
	if($scroll_button == 'yes') {
		$scroll_class = ' veented-slider-with-scroll';
	}
	
	$no_slider = false;
	$hero_section_class = 'veented-slider'; // Image Slider
	
	if(sizeof($images) == 1 || $media_type == 'video') {
		$no_slider = true;
		$hero_section_class = 'hero-section-video';
	}

	$overlay_class = '';
	$animated_class = '';
	
	ob_start();
	
	?>
    
    <div id="hero-section-<?php echo $random_id; ?>" class="hero-section veented-slider-holder<?php echo $overlay_class.$fullscreen_class.$scroll_class; ?>" data-slider-autoplay="<?php echo esc_attr($autoplay); ?>" data-slider-effect="<?php echo esc_attr($slider_effect); ?>">
	
		
		<div class="<?php echo esc_attr($hero_section_class); ?> swiper-containers">
		
			<div class="veented-slider-inner swiper-wrapper">
			
				<?php
				
				if($bg_overlay != 'none') {
					echo '<div class="bg-overlay bg-overlay-'.esc_attr($bg_overlay).'"></div>';
				}
						
				if($media_type == 'images') {	
				
					if ( '' === $images ) {
						$images = '-1,-2,-3';
					}
					
					$images = explode( ',', $images );
					
					$i = 0;
					
					foreach ( $images as $attach_id ): ?>
						<?php
						
						$i++;
						
						$bg_img = wp_get_attachment_image_src($attach_id, 'vntd-bg-image');
						$bg_img_url = $bg_img[0];
						
						?>
						
						<div class="swiper-slide veented-slide swiper-lazy veented-slide-<?php echo $i; ?>" style="background-image:url(<?php echo esc_url($bg_img_url); ?>);" data-background="<?php echo esc_url($bg_img_url); ?>">	
						
						</div>
						
					<?php endforeach;
					
				} elseif($youtube_url != '') {
				
					// VIDEO
					
					echo '<div class="hero-video-holder">';
					
					$row_video_before = '';
					
					wp_enqueue_script('YTPlayer');
					wp_enqueue_style('YTPlayer');
					
					$random_video_id = 'fullscreen-'.rand(1,9999);

					echo '<div id="P2-'.$random_video_id.'" class="player video-container" data-property="{videoURL:\''.esc_url($youtube_url).'\',containment:\'#hero-section-'.$random_id.' > div\',autoPlay:'.esc_attr($video_autoplay).', showControls:'.esc_attr($video_controls).', mute:'.esc_attr($video_mute).', startAt:0,opacity:1}"></div>';
					
					echo '</div>';

				}


				if($height_custom > 0 && $height == 'custom' || $offset != 0) {
					$height_custom = str_replace('px','',$height_custom);
					echo '<style type="text/css">';
					if($height_custom > 0 && $height == 'custom') {
						echo '#hero-section-'.$random_id.' { height: '.esc_attr($height_custom).'px; }';	
					}
					if($offset != 0) {
						echo '#hero-section-'.$random_id.' .inner { padding-top: '.esc_attr($offset).'px; }';
					}
					echo '</style>';			
				}			
				
				?>   
				<div class="hero-section-content">
					<div class="inner">
						<div class="veented-slide-inner veented-slide">
							<?php if($subheading != '') { ?>
							<h3 class="hero-section-subheading veented-slide-secondary-heading<?php echo $animated_class; ?>"> <?php echo esc_textarea($subheading) ?></h3>
							<?php } ?>
							<h2 class="hero-section-heading veented-slide-heading<?php echo $animated_class; ?>"> <?php echo esc_textarea($title) ?></h2>
							<?php if($subtitle != '') { ?>
							<p class="hero-section-subtitle veented-slide-paragraph <?php echo $animated_class; ?>"><?php echo esc_textarea($subtitle) ?></p>
							<?php }
							
							echo '<div class="veented-slide-buttons'.$animated_class.'">';
							
							if($button1_label != '') {
								
								$button1_class = '';
								
								if($button1_style == 'stroke') $button1_class = ' btn-style-stroke';
								
								echo '<a class="btn btn-'.$button1_color.$button1_class.' btn-style-'.esc_attr($button1_style).' hero-section-button1 veented-slide-button1" href="'.$button1_url.'">'.esc_textarea($button1_label).'</a>';
								
							}
							if($button2_label != '') {
							
								$button2_class = '';
								
								if($button2_style == 'stroke') $button2_class = ' btn-style-stroke';
								
								echo '<a class="btn btn-'.$button2_color.$button2_class.' hero-section-button2 veented-slide-button2" href="'.$button2_url.'">'.esc_textarea($button2_label).'</a>';
								
							}
							echo '</div>';
							
							?>
						</div>
						
					</div> 
				</div>
		
			</div>
		
			<?php
			
			
			
			if($bullet_navigation == 'yes' && $no_slider == false) {
			?>
			<div class="veented-slider-pagination swiper-pagination"></div>
			
			<?php
			}
			
			if($arrow_navigation == 'yes' && $no_slider == false) {
			?>
			<div class="swiper-button-next"><i class="fa fa-angle-right"></i></div>
			<div class="swiper-button-prev"><i class="fa fa-angle-left"></i></div>

			<?php
			}
			
			if($scroll_button == 'yes') {
				echo '<div class="veented-slider-scroll-button-holder"><a href="#second" class="scroll veented-slider-scroll-button"><span class="vntd-mouse-dot"></span></a></div>';
			}

			?>
		
		</div>
	
	</div>
	
	<?php
	
	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('waxom_hero_section');
add_shortcode('waxom_hero_section', 'waxom_hero_section');