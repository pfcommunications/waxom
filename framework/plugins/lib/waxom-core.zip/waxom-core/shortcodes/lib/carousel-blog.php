<?php

// Blog Posts Carousel

function waxom_blog_carousel($atts, $content = null) {
	$posts_nr = $ids = $lightbox = $nav = $nav_position = $dots = $margin = $cols = $autoplay = $thumb_space = $style = $excerpt = $carousel_title = $cats = '';
	extract(shortcode_atts(array(
		"posts_nr" => '',
		"cats" => '',
		"ids" => '',
		"lightbox" => '',
		"nav" => 'false',
		"nav_position" => 'bottom',
		"dots" => 'true',
		"dots_align" => 'center',
		"margin" => 30,
		"cols" => 3,
		"autoplay" => 'true',
		"autoplay_timeout" => 7000,
		"thumb_space" => 'yes',
		"style" => 'boxed',
		"hover_style" => 'light',
		"style_meta" => 'minimal',
		"excerpt" => 'yes',
		"carousel_title" => 'Latest News',
		"view_all" => 'View All'
	), $atts));
	

	wp_enqueue_script('owl-carousel', '', '', '', true);
	wp_enqueue_style('owl-carousel');
	
	$margin = 30;
	
	if($thumb_space == 'no') {
		$margin = 0;
	}
	
	
	ob_start();	
	
	echo '<div class="vntd-carousel-holder">';
	
	if($carousel_title) {
		echo '<div class="vntd-carousel-title"><h2>'.esc_textarea($carousel_title);
		if($view_all) {
			echo '<span>/ <a href="'.get_permalink(get_option('page_for_posts')).'">'.esc_textarea($view_all).'</a></span>';
		}
		echo '</h2></div>';
	}
	
	echo '<div class="vntd-carousel vntd-blog-carousel vntd-blog blog-style-'.esc_attr($style).' blog-meta-'.esc_attr($style_meta).' carousel-nav-'.$nav.' nav-position-'.esc_attr($nav_position).' blog-hover-style-'.esc_attr($hover_style).' carousel-dots-align-'.esc_attr($dots_align).'" data-cols="'.$cols.'" data-autoplay="'.esc_attr($autoplay).'" data-margin="'.$margin.'" data-dots="'.$dots.'" data-nav="'.$nav.'">';	
	
		wp_reset_postdata();
		
		$args = array(
			'posts_per_page' => 8,
			'cat'		=> $cats,
			'orderby'	=> 'slug'
		);		
		
		$the_query = new WP_Query($args);
		$i = 0;
		if ($the_query->have_posts()) : while ($the_query->have_posts()) : $the_query->the_post();
		
		//if(!has_post_thumbnail() && $style != "minimal") continue;
		$i++;
		
		$size = 'vntd-portfolio-square';
		
		if($style == "thumb_bg") {
			$size = "vntd-sidebar-landscape";
		}
		
		$img_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), $size);
		$thumb_url = $img_url[0];
		
		
		?>
		<div class="item">

			<div class="blog-item-inner">
				
				<?php if($style != "minimal" && has_post_thumbnail()) { ?>
				<div class="blog-post-thumbnail">
					<div class="member-image-holder">
						<?php waxom_post_meta_extra(); ?>
						<a href="<?php echo get_permalink(get_the_ID()); ?>">
						<img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>">
						<div class="carousel-post-overlay">
							<div class="fa fa-search"></div>
						</div>
						</a>
						
					</div>
				</div>
				<?php 
				} elseif($style == "minimal") { 
					waxom_post_meta_extra(); 
				} 
				?>

				<div class="blog-post-details">
				
					<div class="blog-post-details-inner">
						<?php if($style == "thumb_bg" || $style == "bubble") waxom_post_meta_extra(); ?>
						<h5 class="blog-post-title">
							<a href="<?php echo get_permalink(get_the_ID()); ?>">
							<?php echo get_the_title(get_the_ID()); ?>
							</a>
						</h5>
						
						<?php waxom_post_meta(); ?>
				
						<div class="details">
							<?php echo waxom_excerpt(17, true); ?>		
						</div>
						
					</div>
				</div>
			</div>
		</div>	
							
		<?php		 
		endwhile; endif; wp_reset_postdata();
		
	echo '</div></div>';

	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('blog_carousel');
add_shortcode('blog_carousel', 'waxom_blog_carousel');