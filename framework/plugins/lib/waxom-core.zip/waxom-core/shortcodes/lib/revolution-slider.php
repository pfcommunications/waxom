<?php

// Shortcode Processing


function waxom_revslider($atts, $content=null){
	extract(shortcode_atts(array(
		"alias" => ''
	), $atts));

	return do_shortcode('[rev_slider '.$alias.']');
}
add_shortcode('revslider', 'waxom_revslider');