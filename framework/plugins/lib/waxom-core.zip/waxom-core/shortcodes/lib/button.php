<?php

// Shortcode Processing


function waxom_button($atts, $content = null) {

	$defaultFont = 'fontawesome';
	$defaultIconClass = 'fa fa-info-circle';
	
	extract(shortcode_atts(array(
		"label" => 'Text on the button',
		"url" => '',
		"target" => '_self',
		"color" => 'accent',
		"hover" => '',
		"customcolor" => '',
		"size" => 'regular',
		"style" => '',
		"scroll" => '',
		"align" => '',
		"icon_enabled" => '',
		"icon" => 'heart-o',
		"icon_type" => $defaultFont,
		"icon_fontawesome" => $defaultIconClass,
		"icon_typicons" => '',
		"icon_openiconic" => '',
		"icon_entypo" => '',
		"icon_linecons" => '',
	), $atts));		
	
	$icon = str_replace('fa-','',$icon);
	vc_icon_element_fonts_enqueue( $icon_type );
	
	$iconClass = isset( ${"icon_" . $icon_type} ) ? ${"icon_" . $icon_type} : $defaultIconClass;
	
	$custom_style = $scroll_class = $align_class = $icon_class = $icon_element = '';
	
	if($color == "custom") {
		$custom_style .= ' style="background-color:'.$customcolor.';border-color:'.$customcolor.';';
		if($style == "stroke") {
			$custom_style .= 'color:'.$customcolor.';';
		}
		$custom_style .= '" ';
		
	} elseif(strpos($color,'#') !== false) {
		$custom_style .= ' style="background-color:'.$color.';border-color:'.$color.';';
		if($style == "stroke") {
			$custom_style .= 'color:'.$customcolor.';';
		}
		$custom_style .= '" ';
	}

	
	if($align == 'center') {
		$align_class = ' btn-center';
	}
	
	if($scroll == 'yes') $scroll_class = ' scroll';
	
	// Button Size
	$size_class = $hover_class = '';
	if($size == 'large') {
		$size_class = ' btn-large';
	} elseif($size == 'small') {
		$size_class = ' btn-small';
	}
	
	if($hover == 'accent') {
		$hover_class = ' accent-hover-bg';
	}
	
	if($icon_enabled == "yes") {
		$icon_class = ' btn-icon';
		$icon_element = '<i class="'.$iconClass.'"></i>';
	}
	
	if(!$style) $style = 'default';

	return '<a href="'.$url.'" class="btn btn-style-'.$style.' btn-'.esc_attr($color).$size_class.$scroll_class.$align_class.$hover_class.$icon_class.'" target="'.$target.'"'.$custom_style.'>'.$icon_element.$label.'</a>';

}
remove_shortcode('button');
add_shortcode('button', 'waxom_button');