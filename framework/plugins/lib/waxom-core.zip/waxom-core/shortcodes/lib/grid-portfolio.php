<?php

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//		Portfolio Grid Shortcode
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function waxom_portfolio_grid($atts, $content = null) {
	extract(shortcode_atts(array(
		"filter" => 'yes',
		"filter_style" => 'boxed',
		"filter_counter" => 'yes',
		"filter_color" => 'dark',
		"grid_title" => '',
		"hover_style" => 'simple',
		"animation" => 'quicksand',
		"content_type" => 'default',
		"posts_nr" => '',
		"cats" => '',
		"thumb_style" => 'title_category',
		"thumb_size" => 'square',
		"order" => '',
		"el_position" => '',
		"width" => '',
		"composer" => '',
		"paged_posts" => '',
		"more_url" => '',
		"thumb_space" => 'yes',
		"thumb_space_amount" => '30',
		"cols" => '4',
		"thumb_size" => '',
		"ajax" => 'yes',
		"love" => 'yes',
		"pagination" => 'no'
	), $atts));
	

	wp_enqueue_script('cubePortfolio');
	wp_enqueue_script('cubeConfig');
	wp_enqueue_style('cubePortfolio');
	
	wp_enqueue_script('magnific-popup', '', '', '', true);
	wp_enqueue_style('magnific-popup');
	
	// Define container and item span value
	
	global $post;

	if(!$posts_nr) $posts_nr = "-1";
	$block_id = rand(5,5000);
	
	$layout_class = '';
	$item_class = 'boxed-item col-xs-4';	
	if($thumb_space == 'no') {
		$layout_class = 'fullwidth relative';
		$item_class = 'five';
		if($cols == "4") {
			$item_class = 'four';
		}
	}
	
	$thumb_gap = 30;
	if($thumb_space == "no") $thumb_gap = 0;
	
	if($thumb_space_amount != '30') {
		$thumb_gap = str_replace('px','',$thumb_space_amount);
	}
	
	$rand_id = rand(1,9999);
	ob_start();

	echo '<div class="portfolio vntd-portfolio-grid portfolio-style '.$layout_class.' portfolio-'.$hover_style.' portfolio-'.$thumb_style.' portfolio-cols-'.$cols.' portfolio-counter-'.$filter_counter.' portfolio-filter-'.$filter_color.' portfolio-content-'.$content_type.' portfolio-love-'.$love.'">';
		if($filter == "yes") waxom_filters('project-type',$cats,$filter_style,$grid_title,$rand_id);
		echo '<div id="portfolio-'.$rand_id.'" class="portfolio-items grid-items cbp" data-cols="'.$cols.'" data-animation="'.$animation.'" data-gap="'.$thumb_gap.'" data-filters="portfolio-filters-'.$rand_id.'">';
		
		wp_reset_query();
		
		$paged = waxom_query_pagination();
		
		$cats_arr = explode(" ", $cats);
		$args = array(
			'posts_per_page' => $posts_nr,
			'project-type'		=> $cats,
			'paged' => $paged,
			'post_type' => 'portfolio'
		);
		$the_query = new WP_Query($args); 	
		
		// Default Thumbnail Sizes
		
		$size = "vntd-portfolio-square";	
		if($thumb_size == "auto") $size = "vntd-portfolio-auto";
		if($cols == 1) $size = "vntd-sidebar-landscape";
		
		$data_content = $ajax_class = '';
		
		
		
		if ($the_query->have_posts()) : while ($the_query->have_posts()) : $the_query->the_post();
			
				$img_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), $size);
				$thumb_url = $img_url[0];
				
				// For lightbox zoom
				
				$img_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'large');
				$big_thumb_url = $img_url[0];
				
				$post_link = get_permalink();
				
				$post_link_type = get_post_meta($post->ID,'link_type',TRUE);
				
				if($post_link_type == 'external' && get_post_meta($post->ID,'portfolio_external_url',TRUE)) {
					$data_content = '';
					$ajax_class = '';
					$post_link = get_post_meta($post->ID,'portfolio_external_url',TRUE);
				}
				
				$excerpt = $excerpt_class = ' no-excerpt';
				if(get_post_meta($post->ID,'portfolio_post_excerpt',TRUE)) {
					$excerpt = get_post_meta($post->ID,'portfolio_post_excerpt',TRUE);
					$excerpt_class = ' has-excerpt';
				}
				
				$lightbox_content_class = $item_lightbox_class = '';
				if($content_type == 'lightbox' && $post_link_type != 'link' && $post_link_type != 'external') {
					$item_lightbox_class = ' portfolio-item-lightbox';
					$lightbox_content_class = ' cbp-portfolio-lightbox';
				}
				
				$extra_lightbox_class = '';
				
				if( $hover_style == 'lightbox' ) {
					$extra_lightbox_class = 'cbp-image-lightbox';
					$post_link = $big_thumb_url;
				}
				
				
				
						?>
						
							<div class="item cbp-item <?php echo esc_attr($item_class).$excerpt_class.$item_lightbox_class; ?> <?php echo waxom_portfolio_item_class(); ?>"<?php echo $data_content; ?>>
		
								<div class="item-inner">
		
									<a href="<?php echo esc_url($post_link); ?>" class="work-image<?php echo esc_attr($lightbox_content_class); ?> <?php echo esc_attr( $extra_lightbox_class ); ?>">
		
										<img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>">
		
										<div class="portfolio-item-overlay">
											
											<?php if($hover_style != "bottom") { ?>
											<div class="portfolio-overlay-icons">
												<span class="overlay-icon overlay-icon-link" data-href="<?php echo esc_url($post_link); ?>"><i class="fa fa-link"></i></span>
												<span class="overlay-icon overlay-icon-zoom cbp-image-lightbox" data-href="<?php echo esc_url($big_thumb_url); ?>" href="<?php echo esc_url($big_thumb_url); ?>"><i class="fa fa-search"></i></span>
											</div>
											<?php } ?>
											
											<h3 class="portfolio-overlay-title">
												<?php the_title(); ?>
											</h3>
											
											<div class="portfolio-overlay-cats"><?php waxom_portfolio_overlay_categories(); ?></div>
											<?php if(get_post_meta($post->ID,'portfolio_post_excerpt',TRUE)) { ?>
											<p class="portfolio-overlay-excerpt">
												<?php echo get_post_meta($post->ID,'portfolio_post_excerpt',TRUE); ?>
											</p>
											<?php } ?>
										</div>
		
									</a>
		
								</div>
								
								<?php if($thumb_style && $thumb_style != "simple") { ?>
								<div class="item-outer">
									<h3 class="portfolio-outer-title">
										<a href="<?php echo esc_url($post_link); ?>" class="portfolio-outer-link<?php echo $lightbox_content_class; ?>"><?php the_title(); ?></a>
									</h3>
									<div class="portfolio-outer-cats"><?php waxom_portfolio_overlay_categories(); ?></div>
									<?php if(get_post_meta($post->ID,'portfolio_post_excerpt',TRUE) && $thumb_style == 'title_category_excerpt' || get_post_meta($post->ID,'portfolio_post_excerpt',TRUE) && $thumb_style == 'title_excerpt') { ?>
									<p class="portfolio-outer-excerpt">
										<?php echo get_post_meta($post->ID,'portfolio_post_excerpt',TRUE); ?>
									</p>
									<?php } 
									
									if($love == "yes" && $thumb_style == "title_category") waxom_love_button();
									
									if($thumb_style == "title_excerpt_more") { ?>
									<div class="portfolio-view-more btn btn-dark"><a href="<?php echo esc_url($post_link); ?>"><?php esc_html_e('View More', 'waxom'); ?></a></div>
									
									<?php }	?>
								</div>
								<?php } ?>
							</div>
							
							<?php 
	
	
		endwhile; endif; 
		
		echo '</div>';
		
		if($ajax == 'yes' && $posts_nr > 1) {
			waxom_ajax_pagination($the_query,"portfolio");
			echo '<div id="portfolio-load-posts" class="pagination-wrap"><a href="#" class="btn btn-style-default btn-accent2 btn-larger">'.esc_html__('Load More','waxom').'</a></div>';
			
			
		}

		if($pagination == 'yes') {
			waxom_pagination($the_query);
		}

		
		echo '</div>';
		
		wp_reset_postdata(); 
	
	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('portfolio_grid');
add_shortcode('portfolio_grid', 'waxom_portfolio_grid');