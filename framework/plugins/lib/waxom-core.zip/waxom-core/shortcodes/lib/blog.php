<?php

// Blog Shortcode


function vntd_blog($atts, $content = null) {
	extract(shortcode_atts(array(
		"cats" => '',
		"blog_style" => 'classic',
		"grid_cols" => '3',
		"grid_style" => 'boxed',
		"style_meta" => 'classic',
		"grid_masonry" => 'yes',
		"ajax" => 'no',
		"posts_nr" => '',
		"el_position" => '',
		"width" => '',
	), $atts));
	
	// Get Blog Style

	$blog_grid_style = '';
	
	if($blog_style == "grid" || $blog_style == "timeline") {
	
		wp_enqueue_script('vntdIsotope', '', '', '', true);
		
	}
	
	global $post;
	
	$layout = get_post_meta($post->ID, 'page_layout', true);
	if($layout != "fullwidth") $sidebar_class = "page-sidebar";

	// Define grid item size
	
	ob_start();
	
	echo '<div class="blog blog-index blog-style-'.esc_attr($blog_style).'">';
	
	// The Loop
	
	wp_reset_query(); 
	
	global $more; $more = 0; // Reset the More Tage
	
	echo '<div class="blog-inner blog-style-'.$grid_style.'">';
	
	if($blog_style == "grid" || $blog_style == "timeline") {

		if($blog_style == "timeline") {
			$grid_cols = 2;
		}
		echo '<div class="vntd-grid-container grid-cols-'.esc_attr($grid_cols).' blog-meta-'.esc_attr($style_meta).' grid-style-'.esc_attr($grid_style).'" data-cols="'.esc_attr($grid_cols).'">';
	}
	
	
	wp_reset_postdata();
	
	$paged = waxom_query_pagination();

	$args = array(
		'posts_per_page' => $posts_nr,
		'cat'		=> $cats,
		'orderby'	=> 'slug',
		'paged' => $paged
	);	
	
	$the_query = new WP_Query($args); 	
	
	if ($the_query->have_posts()) : while ($the_query->have_posts()) : $the_query->the_post();
		
		waxom_blog_post_content($layout, $blog_style, $grid_style, $grid_masonry);
		
	endwhile; endif; 
	
	// Loop END

	if($blog_style == "grid" || $blog_style == "timeline") {
		echo "</div>";
	}
		
	waxom_pagination($the_query); // Pagination
	
	if($ajax == 'yes') {
		waxom_ajax_pagination($the_query,"blog");
	}
	
	wp_reset_query(); 
	
	echo '</div></div>';
	
	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('vntd_blog');
add_shortcode('vntd_blog', 'vntd_blog');