<?php

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//		Portfolio Grid Shortcode
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function waxom_team_grid($atts, $content = null) {
	extract(shortcode_atts(array(
		"filter" => 'yes',
		"filter_style" => 'boxed',
		"grid_title" => '',
		"animation" => 'rotateSides',
		"posts_nr" => '',
		"cats" => '',
		"style" => 'simple',
		"thumb_size" => 'square',
		"order" => '',
		"el_position" => '',
		"width" => '',
		"composer" => '',
		"paged_posts" => '',
		"more_url" => '',
		"thumb_space" => '',
		"cols" => '4',
		"thumb_size" => ''
	), $atts));
	
	wp_enqueue_script('cubePortfolio');
	wp_enqueue_script('cubeConfig');
	wp_enqueue_style('cubePortfolio');
	
	wp_enqueue_script('magnific-popup', '', '', '', true);
	wp_enqueue_style('magnific-popup');
	
	// Define container and item span value
	
	global $post;

	if(!$posts_nr) $posts_nr = "-1";
	$block_id = rand(5,5000);
	$rand_id = rand(9,9999);
	$layout_class = '';
	$item_class = 'boxed-item col-xs-4';	
	if($thumb_space == 'no') {
		$layout_class = 'fullwidth relative';
		$item_class = 'five';
		if($cols == "4") {
			$item_class = 'four';
		}
	}
	
	$thumb_gap = 30;
	if($thumb_space == "no") $thumb_gap = 0;

	ob_start();

	echo '<div class="vntd-team vntd-team-grid team-style-'.$style.' '.$layout_class.' ">';
	if($filter == "yes") waxom_filters('member-position',$cats,$filter_style,$grid_title,$rand_id);
	echo '<div class="grid-items team-items" data-cols="'.$cols.'" data-animation="'.$animation.'" data-gap="'.$thumb_gap.'" data-filters="portfolio-filters-'.$rand_id.'">';
	wp_reset_postdata();
	
	$paged = '';
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	
	$cats_arr = explode(" ", $cats);
	$args = array(
		'posts_per_page' => $posts_nr,
		'member-position' => $cats,
		'paged' => $paged,
		'post_type' => 'team'
	);
	$the_query = new WP_Query($args); 	
	
	// Default Thumbnail Sizes
	
	$size = "vntd-square-medium";
	if($cols == 1) $size = "vntd-sidebar-landscape";
	
	$data_content = $ajax_class = '';
	
	if ($the_query->have_posts()) : while ($the_query->have_posts()) : $the_query->the_post();
		
		$img_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), $size);
		$thumb_url = $img_url[0];
		
		// For lightbox zoom
		
		$img_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'large');
		$big_thumb_url = $img_url[0];
		
		$post_link = get_permalink();
		
		$post_link_type = get_post_meta($post->ID,'link_type',TRUE);
		
		if($post_link_type == 'external' && get_post_meta($post->ID,'portfolio_external_url',TRUE)) {
			$data_content = '';
			$ajax_class = '';
			$post_link = get_post_meta($post->ID,'portfolio_external_url',TRUE);
		}
		
		$excerpt = $excerpt_class = ' no-excerpt';
		if(get_post_meta($post->ID,'portfolio_post_excerpt',TRUE)) {
			$excerpt = get_post_meta($post->ID,'portfolio_post_excerpt',TRUE);
			$excerpt_class = ' has-excerpt';
		}
		
				?>
				
					<div class="item cbp-item <?php echo esc_attr($item_class).$excerpt_class; ?> <?php echo waxom_team_item_class(); ?>"<?php echo $data_content; ?>>
						
						<div class="team-member-inner">
			
							<div class="team-member-image">
								<div class="member-image-holder">
									<img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>">
								</div>
							</div>
			
							<div class="team-member-details">
							
								<div class="team-member-details-inner">
			
									<div class="team-member-title">
				
										<h4 class="member-name">
											<?php echo esc_textarea(get_post_meta(get_the_ID(),"member_name",TRUE)); ?>
										</h4>
				
										<h6 class="member-position">
											<?php waxom_team_member_categories(); ?>
										</h6>
									</div>
				
									<div class="team-member-data">
										
										<?php if($excerpt != 'no') { ?>
										<p class="team-member-description normal">
											<?php echo esc_textarea(get_post_meta(get_the_ID(),"member_bio",TRUE)); ?>
										</p>						
										<?php 
										}
										
										$member_socials = array('website','facebook','twitter','googleplus','pinterest','linkedin','instagram','email','vimeo');
										$href_extra = $member_social_icon = '';
										echo '<div class="team-member-icons">';
										foreach($member_socials as $member_social) {
																	
											if(get_post_meta(get_the_ID(),'member_'.$member_social,TRUE)) {
												
												$member_social_icon = $member_social;
												
												if($member_social == 'email') {
													$href_extra = 'mailto:';
													$member_social_icon = 'envelope';
												} elseif( $member_social == 'website') {
													$member_social_icon = 'globe';
												}
												
												echo '<a href="'.esc_url($href_extra.get_post_meta(get_the_ID(),'member_'.$member_social,TRUE)).'" target="_blank" class="member-social '.$member_social.'"><i class="fa fa-'.$member_social_icon.'"></i></a>';
											}				
										
										}
										echo '</div>';
										?>
				
									</div>
								</div>
							</div>
						</div>

					</div>
					
					<?php 


	endwhile; endif; ?>

	<?php 
	
	echo '</div>';
	
	echo '</div>';
	
	wp_reset_postdata(); 
	
	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('team_grid');
add_shortcode('team_grid', 'waxom_team_grid');