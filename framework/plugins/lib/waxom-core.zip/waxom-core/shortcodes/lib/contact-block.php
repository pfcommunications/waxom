<?php

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//		Contact Block
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function waxom_contact_block($atts, $content = null) {
	extract(shortcode_atts(array(
		"phone" => '0123 456 789',
		"address" => 'Waxom, Street Name 6901, Melbourne Australia',
		"email" => 'support@sitename.com',
		"title" => 'Keep in touch',
		"description" => '',
		"style" => 'default',
		"site" => ''
	), $atts));
	
	ob_start();		
    
    ?>
    
	<div class="vntd-contact-block contact-block-<?php echo esc_attr($style); ?>">
		<div class="contact-block-inner">
			<div class="contact-block-header">
			<?php 
			
			if($title) echo '<div class="contact-block-title"><h3>'.esc_html($title).'</h3></div>';
			if($description) echo '<div class="contact-block-description"><p>'.esc_html($description).'</p></div>';
			
			?>
			</div>
			<div class="contact-block-details">
				<?php
				
				if($address) echo '<div class="contact-block-address"><i class="fa fa-map-marker"></i> <span>'.esc_html($address).'</span></div>';
				if($phone) echo '<div class="contact-block-phone"><i class="fa fa-phone"></i> <span>'.esc_html($phone).'</span></div>';
				if($email) echo '<div class="contact-block-email"><i class="fa fa-envelope"></i> <span><a href="mailto:'.esc_html($email).'">'.esc_html($email).'</a></span></div>';
				
				?>
			</div>
		</div>
	</div>
	
	<?php 
	
	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('contact_block');
add_shortcode('contact_block', 'waxom_contact_block');