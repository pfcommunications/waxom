<?php

function waxom_cta($atts, $content=null) {
	extract(shortcode_atts(array(
		"button1_title" => '',
		"button1_subtitle" => '',
		"button1_url" => '',
		"button1_style" => 'default',
		"button2_title" => '',
		"button2_subtitle" => '',
		"button2_url" => '',		
		"text_color" => 'dark',
		"bg_color" => 'none',
		"bg_color_custom" => '',
		"button1_color" => 'accent2',
		"button2_color" => 'accent',
		"style" => '',
		"subtitle" => '',
		"heading" => '',
		"margin_bottom" => '',
		"extra_class" => '',
		"highlight" => 'first',
		"highlight_color" => 'accent'
	), $atts));
	
	$extra_style = $extra_style_color = $return = '';
	
	if($bg_color == "custom" && $bg_color_custom) $extra_style .= " style='background-color:".$bg_color_custom.";'";
	
	if($subtitle) $extra_class = ' cta-with-subtitle';
	
	$return .= '<div class="vntd-cta vntd-cta-style-'.$style.' vntd-cta-color-'.$text_color.' vntd-bg-color-'.$bg_color.$extra_class.'"'.$extra_style.'><div class="inner"><div class="inner-margin">';

	$heading = esc_textarea($heading);
	
	if($highlight == 'first') {
		$heading = preg_replace('/(?<=\>)\b\w*\b|^\w*\b/', '<span class="heading-highlight color-'.$highlight_color.'">$0</span>', $heading);
	}
	
	$return .= '<div class="cta-left col-xs-8"><h1 class="cta-title"'.esc_attr($extra_style_color).'>'.$heading.'</h1>';
	
	if($subtitle) $return .= '<p class="cta-subtitle"'.$extra_style_color.'>'.esc_textarea($subtitle).'</p>';
	
	$return .= '</div>';
	
	$return .= '<div class="cta-right col-xs-4">';

	if($button2_title) $return .= '<a href="'.esc_url($button2_url).'" class="cta-button btn-style-default cta-button2 btn btn-larger btn-'.$button2_color.'">'.esc_textarea($button2_title).'</a>';
	if($button1_title) $return .= '<a href="'.esc_url($button1_url).'" class="cta-button btn-style-'.esc_attr($button1_style).' cta-button1 btn btn-larger btn-'.esc_attr($button1_color).'">'.esc_textarea($button1_title).'</a>';
	
	
	$return .= '</div>';
	
	
	
	$return .= '</div></div></div>';
	
	return $return;
}
remove_shortcode('cta');
add_shortcode('cta', 'waxom_cta');  