<?php

// List Shortcode Processing

function waxom_list($atts, $content=null) {
	extract(shortcode_atts(
		array(
		"icon" => 'check',
		"color" => 'accent',
		"background" => ''
		), $atts)
	);
	
	$background_class = '';
	
	if($background == 'yes') {
		$background_class = 'vntd-list-bg';
	}
	
	return '<ul class="vntd-list vntd-list-'.$color.' '.$background_class.' list-icon-'.$icon.'">'.waxom_do_shortcode($content).'</ul>';
}

function waxom_li($atts, $content=null) {	
	return '<li><i class="fa fa-star-o"></i> '.$content.'</li>';
}

remove_shortcode('list');
remove_shortcode('li');
add_shortcode('list', 'waxom_list');
add_shortcode('li', 'waxom_li');