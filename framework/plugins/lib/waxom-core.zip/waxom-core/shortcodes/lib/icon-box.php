<?php

// Icon Box Shortcode

function waxom_icon_box($atts, $content = null) {

	$defaultFont = 'fontawesome';
	$defaultIconClass = 'fa fa-info-circle';
	
	extract(shortcode_atts(array(
		"icon" => 'heart-o',
		"icon_type" => $defaultFont,
		"icon_fontawesome" => $defaultIconClass,
		"icon_typicons" => '',
		"icon_openiconic" => '',
		"icon_entypo" => '',
		"icon_linecons" => '',
		"icon_pixelicons" => '',
		"style" => 'big-centered-icon',
		"title" => 'Icon Box Title',
		"text" => '',	
		"url" => '',
		"link_button" => 'no',
		"link_button_label" => 'Read more',
		"target" => '_self',
		"text_style" => 'fullwidth',		
		"animated" => '',
		"icon_hover" => '',
		"animation_delay" => 100			
	), $atts));
	
	$icon = str_replace('fa-','',$icon);
	vc_icon_element_fonts_enqueue( $icon_type );
	
	$iconClass = isset( ${"icon_" . $icon_type} ) ? ${"icon_" . $icon_type} : $defaultIconClass;
	
	$aligned_class = ' box';
	if($style == 'left' || $style == 'right') $aligned_class = ' feature-box';
	
	$animated_class = $animated_data = '';
	
	if($animated != 'no') {
		$animated_class = ' animated';
		$animated_data = ' data-animation="fadeIn" data-animation-delay="'.$animation_delay.'"';
	}
	
	$url_extra_class = $icon_hover_class = '';
	
	if($url) {
		$url_extra_class = ' icon-box-with-link';
	}
	
	if($icon_hover != 'no' || $url) {
		$icon_hover_class = ' icon-box-hover';
	}
	
	$output = '<div class="vntd-icon-box icon-box-'.$style.$animated_class.$aligned_class.$url_extra_class.$icon_hover_class.'"'.$animated_data.'>';
	
	if($style == 'boxed-circle') {
		$output .= '<div class="icon-box-inner">';
	}
	
	if($url) {
		$output .= '<a href="' . $url . '" target="' . esc_attr( $target ) . '">';
	}
	
	$output .= '<div class="icon-box-icon">';
	if($style == 'medium-left-triangle' || $style == 'medium-right-triangle' || $style == 'big-centered-triangle') {
		$output .= '<div class="icon-box-triangle"></div>';
	}
	$output .= '<i class="'.$iconClass.'"></i>';
	$output .= '</div><div class="icon-box-content">';
	if($title) $output .= '<h3 class="icon-box-title">'.$title.'</h3>';	
	$output .= '<p class="icon-description">'.$text.'</p>';
	
	if($link_button == 'yes' && $url) {
		if($style == 'boxed-circle') {
			$output .= '<div class="icon-box-link-icon"><i class="fa fa-angle-right"></i></div>';
		} else {
			$output .= '<div class="icon-box-link-button">'.$link_button_label.' <i class="fa fa-caret-right"></i></div>';
		}
	}
	
	$output .= '</div>';
	
	if($url) {
		$output .= '</a>';
	}
	
	if($style == 'boxed-circle') {
		$output .= '</div>';
	}
	
	$output .= '</div>';
	
	return $output;
	
}
remove_shortcode('icon_box');
add_shortcode('icon_box', 'waxom_icon_box');