<?php

// Blog Posts Carousel

function waxom_team_carousel($atts, $content = null) {
	extract(shortcode_atts(array(
		"posts_nr" => '',
		"ids" => '',
		"lightbox" => '',
		"nav" => 'false',
		"nav_position" => 'bottom',
		"dots" => 'true',
		"margin" => 30,
		"cols" => 4,
		"autoplay" => 'true',
		"autoplay_timeout" => 7000,
		"thumb_space" => 'yes',
		"style" => 'simple',
		"excerpt" => 'yes',
		"carousel_title" => ''
	), $atts));
	
	wp_enqueue_script('owl-carousel', '', '', '', true);
	wp_enqueue_style('owl-carousel');
	
	$margin = 30;
	
	if($thumb_space == 'no') {
		$margin = 0;
	}
	
	ob_start();	
	
	echo '<div class="vntd-carousel-holder">';
	
	if($carousel_title) {
		echo '<div class="vntd-carousel-title"><h2>'.$carousel_title.'</h2></div>';
	}
	
	echo '<div class="vntd-carousel vntd-team-carousel vntd-team team-style-'.$style.' team-carousel-cols-'.$cols.' carousel-nav-'.$nav.' nav-position-'.$nav_position.'" data-cols="'.$cols.'" data-autoplay="'.$autoplay.'" data-autoplay-timeout="'.esc_attr($autoplay_timeout).'" data-margin="'.$margin.'" data-dots="'.$dots.'" data-nav="'.$nav.'">';	
	
		wp_reset_postdata();
		
		if($ids) {
			$ids_array = explode(" ", $ids);
			$args = array(
				'posts_per_page' => $posts_nr,
				'post_type' => 'team',
				'post__in' => $ids_array
			);
		} else {
			$args = array(
				'posts_per_page' => $posts_nr,
				'post_type' => 'team'
			);
		}
		
		
		$the_query = new WP_Query($args);
		$i = 0;
		if ($the_query->have_posts()) : while ($the_query->have_posts()) : $the_query->the_post();
		$i++;
		$img_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'vntd-square-medium');
		$thumb_url = $img_url[0];
		?>
		<div class="item">

			<div class="team-member-inner">

				<div class="team-member-image">
					<div class="member-image-holder">
						<img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title(); ?>">
					</div>
				</div>

				<div class="team-member-details">
				
					<div class="team-member-details-inner">

						<div class="team-member-title">
	
							<h4 class="member-name">
								<?php echo esc_textarea(get_post_meta(get_the_ID(),"member_name",TRUE)); ?>
							</h4>
	
							<h6 class="member-position">
								<?php waxom_team_member_categories(); ?>
							</h6>
						</div>
	
						<div class="team-member-data">
							
							<?php if($excerpt != 'no') { ?>
							<p class="team-member-description normal">
								<?php echo get_post_meta(get_the_ID(),"member_bio",TRUE); ?>
							</p>						
							<?php 
							}
							
							$member_socials = array('website','facebook','twitter','googleplus','pinterest','linkedin','instagram','email','vimeo');
							$href_extra = $member_social_icon = '';
							echo '<div class="team-member-icons">';
							foreach($member_socials as $member_social) {
														
								if(get_post_meta(get_the_ID(),'member_'.$member_social,TRUE)) {
									
									$member_social_icon = $member_social;
									
									if($member_social == 'email') {
										$href_extra = 'mailto:';
										$member_social_icon = 'envelope';
									}
									
									echo '<a href="'.esc_url($href_extra.get_post_meta(get_the_ID(),'member_'.$member_social,TRUE)).'" target="_blank" class="member-social '.$member_social.'"><i class="fa fa-'.$member_social_icon.'"></i></a>';
								}				
							
							}
							echo '</div>';
							?>
	
						</div>
					</div>
				</div>
			</div>
		</div>	
							
		<?php		 
		endwhile; endif; wp_reset_postdata();
		
	echo '</div></div>';

	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('team_carousel');
add_shortcode('team_carousel', 'waxom_team_carousel');