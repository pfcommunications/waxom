<?php

// Shortcode Processing

function waxom_pricing_box($atts, $content) {
	extract(shortcode_atts(array(
		"featured" 		=> 'no',
		"title" 		=> '',
		"features" 		=> '',
		"button_label" 	=> 'Buy Now',
		"period" 		=> 'per year',
		"price" 		=> '$99',
		"button_url" 	=> '',
		"animated" 		=> 'yes',
		"animation_delay" => '',
		"color" 		=> 'light_gray',
		"color_custom" 	=> '',
		"info_box" 		=> '',
		"button_color" 	=> '',
		"border_radius" => 'none'
	), $atts));
	
	$animated_class = $animation_data = $featured_class = $info_class = $color_class = $color_style = $color_bg_style = $button_color_style = $button_color_class = $color_style_h3 = '';
	
	if($animated != 'no') {
		$animated_class = ' animated';
		$animated_data = ' data-animation="fadeIn" data-animation-delay="'.$animation_delay.'"';
	}
	
	if($featured == 'yes') $featured_class = " active";
	if($info_box == 'yes') $info_class = " info-box";
	$features_arr = explode(',',$features);	
	
	$rand_id = "pricing-box-".rand(1,9999);
	
	if($color == "custom") {
		echo '<style type="text/css"> #'.$rand_id.' h3,#page-content #'.$rand_id.' a.btn { background-color:'.$color_custom.' !important; }
		#'.$rand_id.' h4 { color:'.$color_custom.'; }
		#'.$rand_id.' h3:after { border-top-color:'.$color_custom.'; } </style>';
		
	} else {
		$color_class = " pricing-box-color-".$color;
	}
	
	if($button_color == 'box-color' || $featured == 'yes') {
		$button_color_class = ' pricing-button-color-'.$color;
		if($color == "custom") {
			$button_color_style = $color_bg_style;
		}
		
	}
	
	$border_radius_class = ' pricing-box-radius-all';
	
	if($border_radius == 'none') {
		$border_radius_class = '';
	} elseif($border_radius == 'left') {
		$border_radius_class = ' pricing-box-radius-left';
	} elseif($border_radius == 'right') {
		$border_radius_class = ' pricing-box-radius-right';
	}
	
	
	
	$output = '<div id="'.$rand_id.'" class="vntd-pricing-box '.$featured_class.$info_class.$color_class.$button_color_class.$animated_class.$border_radius_class.'"'.$animated_data.'>';	
	$output .= '<h3>'.$title.'</h3><h4>'.$price.'<span>'.$period.'</span></h4>';
	$output .= '<ul class="pricing-box-features">';
	
	foreach($features_arr as $single_feature) {
		if (strpos($single_feature,'fa-') !== false) {
			$single_feature = '<i class="fa '.$single_feature.'"></i>';
		}
		$output .= '<li>'.$single_feature.'</li>';
	}
	
	$output .= '</ul>';
	
	if(!$button_url) $button_url = '#';
	
	if($button_label) {
		$output .= '<div class="pricing-box-button"><a href="'.$button_url.'" target="_blank" class="btn btn-large">'.$button_label.'</a></div>';
	}

	$output .= '</div>';
	
	return $output;
	
}
remove_shortcode('pricing_box');
add_shortcode('pricing_box', 'waxom_pricing_box');  