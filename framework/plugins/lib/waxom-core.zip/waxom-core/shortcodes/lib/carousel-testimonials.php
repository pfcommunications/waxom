<?php

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//		Testimonials Carousel
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function waxom_testimonials($atts, $content = null) {
	extract(shortcode_atts(array(
		"posts_nr" => '',
		"style" => 'simple',
		"cols" => 4,
		"autoplay" => 'true',
		"autoplay_timeout" => 7000,
		"thumb_space" => 'yes',
		"style" => 'simple',
		"excerpt" => 'yes',
		"carousel_title" => '',
		"nav" => 'false',
		"nav_position" => 'bottom',
		"dots" => 'true',
	), $atts));
	
	$holder_class = 'vntd-carousel-holder';

	if($style == "simple" || $style == "minimal") {
	
		wp_enqueue_script('owl-carousel', '', '', '', true);
		wp_enqueue_style('owl-carousel');
		
		
	} elseif($style == 'tabs') {
		$holder_class = 'vntd-testimonials-tabs-holder';
	} elseif($style == "grid") {
		$holder_class = 'vntd-testimonials-grid';
	}
	
	ob_start();		
	
	echo '<div class="'.$holder_class.'">';
		
		if($style == "simple" || $style == "minimal") {
			if($carousel_title) {
				echo '<div class="vntd-carousel-title"><h2>'.$carousel_title.'</h2></div>';
			}
			echo '<div class="vntd-carousel vntd-testimonials-carousel vntd-testimonials testimonials-cols-'.$cols.' testimonials-style-'.$style.' carousel-nav-'.$nav.' nav-position-'.$nav_position.'" data-cols="'.$cols.'" data-effect="fade" data-autoplay="'.$autoplay.'" data-autoplay-timeout="'.esc_attr($autoplay_timeout).'" data-margin="30" data-dots="'.$dots.'" data-nav="'.$nav.'">';
		} elseif($style == "tabs") {
			echo '<div class="vntd-testimonials-tabs vntd-testimonials">';
		} else {
			echo '<div class="vntd-testimonials-grid vntd-testimonials cols-'.$cols.'">';
		}
		
		wp_reset_postdata();
				

		$args = array(
			'posts_per_page' => $posts_nr,
			'post_type' => 'testimonials'
		);
		
		$i = 0;
		$half = round($posts_nr/2);
		$extra_class = '';
		$the_query = new WP_Query($args);
		

		if ($the_query->have_posts()) : while ($the_query->have_posts()) : $the_query->the_post();
		$i++;
		$extra_class = '';
		if($i == $half) $extra_class = ' active-item';
		?>
		<div class="item testimonial-item<?php echo esc_attr($extra_class); ?>">
		
			<div class="testimonial-inner">
			
				<div class="testimonial-data">
					<div class="testimonial-content">
						<div class="testimonial-content-inner">
							<p>
							<?php echo esc_textarea(get_post_meta(get_the_id(), 'testimonial_content', true)); ?>
							</p>
						</div>
						<div class="testimonial-content-arrow">
							<div class="testimonial-content-arrow-inner"></div>
						</div>
					</div>
					
				</div>
				
				<div class="testimonial-meta">
					<?php if($style != "minimal") { ?>
					<div class="testimonial-avatar">
						<img src="<?php echo waxom_thumb(130,130); ?>" alt>
					</div>
					<?php } ?>
					<div class="testimonial-author">
						<h5><?php echo esc_textarea(get_post_meta(get_the_id(), 'name', true)); ?><?php 
						if($style != 'tabs' && $style != 'minimal') echo ', ';
						echo '<span class="testimonial-role">'.esc_textarea(get_post_meta(get_the_id(), 'role', true)).'</span>'; 
						?></h5>
					</div>
				</div>
			</div>
		
		</div>
		
		<?php
		
		endwhile; endif; wp_reset_postdata();
		
		// Fixer element
		if($style == 'tabs') {
			echo '<div class="item testimonial-item fixer-item"><div class="testimonial-meta"><div class="testimonial-avatar not-clickable"><div class="testimonial-fixer"></div></div></div></div>';
		}
		
	echo '</div></div>';

	$content = ob_get_contents();
	ob_end_clean();
	
	return $content;
	
}
remove_shortcode('testimonials');
add_shortcode('testimonials', 'waxom_testimonials');