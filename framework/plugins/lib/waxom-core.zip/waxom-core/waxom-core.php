<?php
   /*
   Plugin Name: Waxom Core
   Plugin URI: http://themeforest.net/user/Veented
   Description: Core functionalities for Waxom Theme.
   Version: 1.2.0
   Author: Veented
   Author URI: http://themeforest.net/user/Veented
   License: GPL2
   */
   
   	// Load Custom Post Types
	
   	require_once('custom-post-types/portfolio/portfolio-functions.php'); 		// Portfolio Post Type
   	require_once('custom-post-types/team/team-functions.php'); 					// Team Member Post Type
   	require_once('custom-post-types/testimonials/testimonials-functions.php'); 	// Testimonial Post Type
   	require_once('custom-post-types/veented-slider/slider-functions.php'); 		// Veented Slider
   	require_once('post-likes/post-like.php'); 
   
   	// Shortcodes
   
   	require_once('shortcodes/shortcodes.php');
   	
   	// Redux Importer
   	
   	if(!function_exists('waxom_redux_register_custom_extension_loader')) :
   	    function waxom_redux_register_custom_extension_loader($ReduxFramework) {
   	        $path    = dirname( __FILE__ ) . '/demo-importer/';
   	            $folders = scandir( $path, 1 );
   	            foreach ( $folders as $folder ) {
   	                if ( $folder === '.' or $folder === '..' or ! is_dir( $path . $folder ) ) {
   	                    continue;
   	                }
   	                $extension_class = 'ReduxFramework_Extension_' . $folder;
   	                if ( ! class_exists( $extension_class ) ) {
   	                    // In case you wanted override your override, hah.
   	                    $class_file = $path . $folder . '/extension_' . $folder . '.php';
   	                    $class_file = apply_filters( 'redux/extension/' . $ReduxFramework->args['opt_name'] . '/' . $folder, $class_file );
   	                    if ( $class_file ) {
   	                        require_once( $class_file );
   	                    }
   	                }
   	                if ( ! isset( $ReduxFramework->extensions[ $folder ] ) ) {
   	                    $ReduxFramework->extensions[ $folder ] = new $extension_class( $ReduxFramework );
   	                }
   	            }
   	    }
   	    // Modify {$redux_opt_name} to match your opt_name
   	    add_action("redux/extensions/waxom_options/before", 'waxom_redux_register_custom_extension_loader', 0);
   	
   	endif;
   	
   	if ( !function_exists( 'wbc_extended_example' ) ) {
   		function wbc_extended_example( $demo_active_import , $demo_directory_path ) {
   			reset( $demo_active_import );
   			$current_key = key( $demo_active_import );
   			/************************************************************************
   			* Import slider(s) for the current demo being imported
   			*************************************************************************/
   			if ( class_exists( 'RevSlider' ) ) {
   				//If it's demo3 or demo5
   				$wbc_sliders_array = array(
   					'demo-main' => 'revslider-portfolio1.zip', //Set slider zip name
   					'demo-business-rev' => 'revslider-business1.zip' //Set slider zip name
   				);
   				if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_sliders_array ) ) {
   					$wbc_slider_import = $wbc_sliders_array[$demo_active_import[$current_key]['directory']];
   					if ( file_exists( $demo_directory_path.$wbc_slider_import ) ) {
   						$slider = new RevSlider();
   						$slider->importSliderFromPost( true, true, $demo_directory_path.$wbc_slider_import );
   					}
   				}
   			}
   			/************************************************************************
   			* Setting Menus
   			*************************************************************************/
   			// If it's demo1 - demo6
   			$wbc_menu_array = array( 'demo-main', 'demo-business-rev');
   			
   			if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && in_array( $demo_active_import[$current_key]['directory'], $wbc_menu_array ) ) {
   				$top_menu = get_term_by( 'name', 'Main Navigation', 'nav_menu' );
   				if ( isset( $top_menu->term_id ) ) {
   					set_theme_mod( 'nav_menu_locations', array(
   							'primary' => $top_menu->term_id
   						)
   					);
   				}
   			}
   			/************************************************************************
   			* Set HomePage
   			*************************************************************************/
   			// array of demos/homepages to check/select from
   			$wbc_home_pages = array(
   				'demo-main' => 'Home Portfolio Rev Slider',
   				'demo-business-rev' => 'Home Business Rev Slider'
   			);
   			if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_home_pages ) ) {
   				$page = get_page_by_title( $wbc_home_pages[$demo_active_import[$current_key]['directory']] );
   				if ( isset( $page->ID ) ) {
   					update_option( 'page_on_front', $page->ID );
   					update_option( 'show_on_front', 'page' );
   				}
   			}
   		}
   		
   		// Uncomment the below
   		add_action( 'wbc_importer_after_content_import', 'wbc_extended_example', 10, 2 );
   	}
   
?>